<?php session_start();
include "../config.php";
include "modul.php";?>
<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.10.1/dist/css/uikit.min.css" />
    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.10.1/dist/js/uikit.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/uikit@3.10.1/dist/js/uikit-icons.min.js"></script>
     <script src="https://kit.fontawesome.com/18fedc45de.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="style.css">
	<title>Продукты</title>
</head>
<body>
<header>
  <h1>Магазин сладюшек</h1>
</header>
 <div>
        <div class="uk-background-fixed" style="background-image: url(images/fon1.png); ">
            <h2 class="Top9">Вкуснейшие товары!
            <br>
            Эти товары чаще его покупают и самое главное, чаще всего это самые вкусные товары на данный момент.
            <br>
            Купи их и убедись в этом!
            </h2>
        </div>
    </div>
    <br>
     <div class="uk-container">
       <?php $tovars = getTovars($connection); ?>
       <div class="uk-child-width-1-3@m" uk-grid>
        <?php foreach($tovars as $tovar){ ?>
             <div>
               <div id="modal-close-default" uk-modal>
          <div class="uk-modal-dialog uk-modal-body">

          <button class="uk-modal-close-default" type="button" uk-close></button>
          <h2 class="uk-modal-title"></h2>

          <p><?php echo $tovar['t_desc'] ?> </p>

      </div>
  </div>
        <div class="uk-card uk-card-default">
            <div class="uk-card-media-top">
                <img src="images/light.jpg" alt="">
              </div>
                 <div class="uk-card-body">
                    <h3 class="uk-card-title"><?php echo $tovar['t_name'] ?></h3>
                         <p><?php echo $tovar['t_coast'] ?> грн.</p>
                         <button class="uk-button uk-button-default" type="button" uk-toggle="target: #modal-close-default">Узнать больше</button>
                  </div>
              </div>
           </div>
        <?php } ?>
       </div>
     </div>
     <h2 class="Top9">Отзывы о топе товарав</h2>

        <div class="uk-background-fixed" style="background-image: url(images/fon1.png); height:100%">
            <div class="uk-container uk-container-small">
               <div class="wrapper">
              <div class="uk-card uk-card-default uk-width-1-2@m" >
    <div class="uk-card-header">
        <div class="uk-grid-small uk-flex-middle" uk-grid>
            <div class="uk-width-auto">
                <img class="uk-border-circle" width="40" height="40" src="images/avatar.jpg">
            </div>
            <div class="uk-width-expand">
                <h3 class="uk-card-title uk-margin-remove-bottom">Юра</h3>
                <p class="uk-text-meta uk-margin-remove-top"><time datetime="2022-02-04">Февраль 4, 2022год</time></p>
            </div>
        </div>
    </div>
     <div class="uk-card-body">
        <p>Пончики классные, я наелся, если бы ещё деньги остались купил бы еще.</p>
    </div>
  </div>
                    <div class="uk-card uk-card-default uk-width-1-2@m">
    <div class="uk-card-header">
        <div class="uk-grid-small uk-flex-middle" uk-grid>
            <div class="uk-width-auto">
                <img class="uk-border-circle" width="40" height="40" src="images/avatar.jpg">
            </div>
            <div class="uk-width-expand">
                <h3 class="uk-card-title uk-margin-remove-bottom">Василий</h3>
                <p class="uk-text-meta uk-margin-remove-top"><time datetime="2022-02-04">Февраль 4, 2022год</time></p>
            </div>
        </div>
    </div>
    <div class="uk-card-body">
        <p>Набор шоколадок безподобен! Жена восторге</p>
    </div>
             </div>
          </div>
          <div class="wrapper">
              <div class="uk-card uk-card-default uk-width-1-2@m">
    <div class="uk-card-header">
        <div class="uk-grid-small uk-flex-middle" uk-grid>
            <div class="uk-width-auto">
                <img class="uk-border-circle" width="40" height="40" src="images/avatar.jpg">
            </div>
            <div class="uk-width-expand">
                <h3 class="uk-card-title uk-margin-remove-bottom">Лилия</h3>
                <p class="uk-text-meta uk-margin-remove-top"><time datetime="2022-02-04">Февраль 4, 2022год</time></p>
            </div>
        </div>
    </div>
     <div class="uk-card-body">
        <p>Почему бы не сделать набор разных баточников, как в шоколадках?</p>
    </div>
  </div>
                    <div class="uk-card uk-card-default uk-width-1-2@m">
    <div class="uk-card-header">
        <div class="uk-grid-small uk-flex-middle" uk-grid>
            <div class="uk-width-auto">
                <img class="uk-border-circle" width="40" height="40" src="images/avatar.jpg">
            </div>
            <div class="uk-width-expand">
                <h3 class="uk-card-title uk-margin-remove-bottom">Максим</h3>
                <p class="uk-text-meta uk-margin-remove-top"><time datetime="2022-02-04">Февраль 4, 2022год</time></p>
            </div>
        </div>
    </div>
    <div class="uk-card-body">
        <p>Пряники от Зины, прикольно)</p>
    </div>
             </div>
          </div>
        </div>
      </div>
 <footer>
       <nav class="nav">
                  <a class="nav__link" href="../spisok.php">Список участников</a>
                  <a class="nav__link" href="../Register.php">Присоеденится к проекту</a>
                  <a class="nav__link" href="../index.php">Главная</a>
              </nav>
            <h2 class="Top9">Соц сети:</h2>
                <a class="social__item" href=""><i class="fab fa-telegram"></i></a>
                <a class="social__item" href=""><i class="fab fa-twitter"></i></a>
                <a class="social__item" href=""><i class="fab fa-instagram"></i></a>
                <a class="social__item" href=""><i class="fab fa-youtube"></i></a>
    </footer>
</body>
</html>